<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="header-container">
        <div class="site-logo">
            <?php
            $logo = get_theme_mod('cafedeluxe_logo');
            if ($logo) {
                echo '<img src="' . esc_url($logo) . '" alt="' . get_bloginfo('name') . '">';
            } else {
                echo '<h1 class="site-title">' . get_bloginfo('name') . '</h1>';
            }
            ?>
        </div>
        
        <nav class="main-navigation">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => false,
                'fallback_cb' => false
            ));
            ?>
        </nav>
        
        <div class="header-icons">
            <div class="cart-icon">
                <a href="<?php echo wc_get_cart_url(); ?>">
                    <i class="fas fa-shopping-cart"></i>
                    <span class="cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                </a>
            </div>
            
            <div class="account-icon">
                <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">
                    <i class="fas fa-user"></i>
                </a>
            </div>
            
            <div class="mobile-menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </div>
</header>