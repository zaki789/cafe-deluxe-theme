<?php
/**
 * AJAX Menu Template Part
 */

// دریافت دسته‌بندی‌های محصولات
$product_categories = get_terms(array(
    'taxonomy' => 'product_cat',
    'hide_empty' => true,
    'orderby' => 'menu_order',
    'order' => 'ASC'
));

// دریافت تنظیمات از Customizer
$menu_title = get_theme_mod('menu_section_title', __('منوی ما', 'cafedeluxe'));
$menu_layout = get_theme_mod('menu_layout', 'grid');
$products_per_page = get_theme_mod('products_per_page', 12);
?>

<section class="ajax-menu-section" id="menu-section">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title"><?php echo esc_html($menu_title); ?></h2>
            
            <?php
            $menu_description = get_theme_mod('menu_description', '');
            if ($menu_description):
            ?>
                <p class="section-description"><?php echo esc_html($menu_description); ?></p>
            <?php endif; ?>
        </div>

        <!-- فیلتر دسته‌بندی‌ها -->
        <div class="menu-filters">
            <div class="filter-buttons">
                <button class="filter-btn active" data-category="all" data-filter="*">
                    <span class="filter-icon">🍽️</span>
                    <span class="filter-text"><?php _e('همه', 'cafedeluxe'); ?></span>
                </button>
                
                <?php foreach ($product_categories as $category): 
                    $category_icon = get_term_meta($category->term_id, 'category_icon', true);
                    $category_color = get_term_meta($category->term_id, 'category_color', true);
                ?>
                    <button class="filter-btn" 
                            data-category="<?php echo esc_attr($category->term_id); ?>" 
                            data-filter=".category-<?php echo esc_attr($category->slug); ?>"
                            style="<?php echo $category_color ? '--category-color: ' . esc_attr($category_color) : ''; ?>">
                        <span class="filter-icon">
                            <?php echo $category_icon ?: '📦'; ?>
                        </span>
                        <span class="filter-text"><?php echo esc_html($category->name); ?></span>
                        <span class="product-count">(<?php echo esc_html($category->count); ?>)</span>
                    </button>
                <?php endforeach; ?>
            </div>
            
            <!-- جستجو در منو -->
            <div class="menu-search">
                <input type="text" class="search-input" placeholder="<?php _e('جستجو در منو...', 'cafedeluxe'); ?>">
                <button class="search-btn">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>

        <!-- حالت‌های نمایش -->
        <div class="view-options">
            <button class="view-option <?php echo $menu_layout === 'grid' ? 'active' : ''; ?>" data-view="grid">
                <i class="fas fa-th"></i>
            </button>
            <button class="view-option <?php echo $menu_layout === 'list' ? 'active' : ''; ?>" data-view="list">
                <i class="fas fa-list"></i>
            </button>
        </div>

        <!-- محفظه محصولات -->
        <div class="products-container">
            <div class="products-loading">
                <div class="loading-spinner">
                    <div class="spinner"></div>
                    <p><?php _e('در حال بارگذاری محصولات...', 'cafedeluxe'); ?></p>
                </div>
            </div>
            
            <div class="products-<?php echo esc_attr($menu_layout); ?>" id="products-grid">
                <!-- محصولات از طریق AJAX لود می‌شوند -->
            </div>
            
            <div class="no-products-message" style="display: none;">
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <h3><?php _e('محصولی یافت نشد', 'cafedeluxe'); ?></h3>
                    <p><?php _e('هیچ محصولی در این دسته‌بندی وجود ندارد.', 'cafedeluxe'); ?></p>
                </div>
            </div>
        </div>

        <!-- صفحه‌بندی -->
        <div class="pagination-container" style="display: none;">
            <div class="pagination">
                <button class="pagination-btn prev" disabled>
                    <i class="fas fa-chevron-right"></i>
                    <?php _e('قبلی', 'cafedeluxe'); ?>
                </button>
                <div class="page-numbers"></div>
                <button class="pagination-btn next">
                    <?php _e('بعدی', 'cafedeluxe'); ?>
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
        </div>
    </div>
</section>

<style>
.ajax-menu-section {
    padding: 80px 0;
    background: var(--background-color);
}

.section-header {
    text-align: center;
    margin-bottom: 50px;
}

.section-description {
    color: #666;
    font-size: 1.1rem;
    max-width: 600px;
    margin: 15px auto 0;
}

.menu-filters {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    flex-wrap: wrap;
    gap: 20px;
}

.filter-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    flex: 1;
}

.filter-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: white;
    border: 2px solid #e0e0e0;
    border-radius: 25px;
    cursor: pointer;
    transition: all 0.3s ease;
    color: var(--text-color);
}

.filter-btn.active,
.filter-btn:hover {
    background: var(--primary-color);
    border-color: var(--primary-color);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.filter-icon {
    font-size: 1.1rem;
}

.product-count {
    font-size: 0.8rem;
    opacity: 0.7;
}

.menu-search {
    display: flex;
    background: white;
    border-radius: 25px;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.search-input {
    border: none;
    padding: 12px 20px;
    outline: none;
    min-width: 250px;
}

.search-btn {
    border: none;
    background: var(--primary-color);
    color: white;
    padding: 12px 20px;
    cursor: pointer;
    transition: background 0.3s;
}

.search-btn:hover {
    background: var(--accent-color);
}

.view-options {
    display: flex;
    gap: 10px;
    margin-bottom: 30px;
    justify-content: center;
}

.view-option {
    padding: 10px 15px;
    background: white;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    color: #666;
    transition: all 0.3s;
}

.view-option.active,
.view-option:hover {
    border-color: var(--primary-color);
    color: var(--primary-color);
    background: rgba(139, 69, 19, 0.1);
}

.products-container {
    position: relative;
    min-height: 400px;
}

.products-loading {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 60px 0;
}

.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 30px;
}

.products-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.products-list .product-card {
    display: flex;
    flex-direction: row;
}

.products-list .product-image {
    width: 200px;
    height: 150px;
    flex-shrink: 0;
}

.products-list .product-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #666;
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 20px;
    opacity: 0.5;
}

.pagination-container {
    margin-top: 50px;
}

.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
}

.pagination-btn {
    padding: 10px 20px;
    border: 2px solid #e0e0e0;
    background: white;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.pagination-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.pagination-btn:not(:disabled):hover {
    border-color: var(--primary-color);
    color: var(--primary-color);
}

.page-numbers {
    display: flex;
    gap: 5px;
}

.page-number {
    padding: 8px 15px;
    border: 2px solid #e0e0e0;
    background: white;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
}

.page-number.active,
.page-number:hover {
    border-color: var(--primary-color);
    background: var(--primary-color);
    color: white;
}

/* ریسپانسیو */
@media (max-width: 768px) {
    .menu-filters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .filter-buttons {
        justify-content: center;
    }
    
    .menu-search {
        width: 100%;
    }
    
    .search-input {
        min-width: auto;
        flex: 1;
    }
    
    .products-grid {
        grid-template-columns: 1fr;
    }
    
    .products-list .product-card {
        flex-direction: column;
    }
    
    .products-list .product-image {
        width: 100%;
        height: 200px;
    }
}
</style>