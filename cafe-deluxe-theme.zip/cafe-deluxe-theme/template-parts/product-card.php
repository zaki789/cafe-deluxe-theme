<?php
/**
 * Product Card Template Part
 */

global $product;

if (!$product) {
    return;
}

$product_id = $product->get_id();
$product_title = $product->get_name();
$product_description = $product->get_short_description();
$product_price = $product->get_price_html();
$product_image = get_the_post_thumbnail_url($product_id, 'medium');
$product_categories = get_the_terms($product_id, 'product_cat');
$category_classes = '';

if ($product_categories && !is_wp_error($product_categories)) {
    foreach ($product_categories as $category) {
        $category_classes .= ' category-' . $category->slug;
    }
}

// بررسی موجودی
$is_in_stock = $product->is_in_stock();
$stock_status = $product->get_stock_status();
?>

<div class="product-card <?php echo esc_attr($category_classes); ?>" data-product-id="<?php echo esc_attr($product_id); ?>">
    <div class="product-badges">
        <?php if ($product->is_on_sale()): ?>
            <span class="badge sale"><?php _e('فروش', 'cafedeluxe'); ?></span>
        <?php endif; ?>
        
        <?php if (!$is_in_stock): ?>
            <span class="badge out-of-stock"><?php _e('ناموجود', 'cafedeluxe'); ?></span>
        <?php endif; ?>
        
        <?php if ($product->is_featured()): ?>
            <span class="badge featured"><?php _e('پیشنهاد ویژه', 'cafedeluxe'); ?></span>
        <?php endif; ?>
    </div>
    
    <div class="product-image">
        <?php if ($product_image): ?>
            <img src="<?php echo esc_url($product_image); ?>" alt="<?php echo esc_attr($product_title); ?>">
        <?php else: ?>
            <div class="no-image"><?php _e('بدون تصویر', 'cafedeluxe'); ?></div>
        <?php endif; ?>
        
        <div class="product-actions">
            <button class="action-btn quick-view" data-product-id="<?php echo esc_attr($product_id); ?>">
                <i class="fas fa-eye"></i>
            </button>
            <button class="action-btn add-to-wishlist" data-product-id="<?php echo esc_attr($product_id); ?>">
                <i class="fas fa-heart"></i>
            </button>
        </div>
    </div>
    
    <div class="product-info">
        <?php if ($product_categories && !is_wp_error($product_categories)): ?>
            <div class="product-category">
                <?php echo esc_html($product_categories[0]->name); ?>
            </div>
        <?php endif; ?>
        
        <h3 class="product-title">
            <a href="<?php echo get_permalink($product_id); ?>">
                <?php echo esc_html($product_title); ?>
            </a>
        </h3>
        
        <?php if ($product_description): ?>
            <div class="product-description">
                <?php echo wp_trim_words($product_description, 15); ?>
            </div>
        <?php endif; ?>
        
        <div class="product-meta">
            <?php if ($product->get_rating_count() > 0): ?>
                <div class="product-rating">
                    <div class="stars">
                        <?php
                        $rating = $product->get_average_rating();
                        for ($i = 1; $i <= 5; $i++):
                            $class = ($i <= $rating) ? 'fas fa-star' : 'far fa-star';
                        ?>
                            <i class="<?php echo $class; ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <span class="rating-count">(<?php echo $product->get_rating_count(); ?>)</span>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="product-footer">
            <div class="product-price">
                <?php echo $product_price; ?>
            </div>
            
            <div class="product-actions-main">
                <?php if ($is_in_stock): ?>
                    <button class="add-to-cart-btn" data-product-id="<?php echo esc_attr($product_id); ?>">
                        <i class="fas fa-shopping-cart"></i>
                        <span><?php _e('افزودن به سبد', 'cafedeluxe'); ?></span>
                    </button>
                <?php else: ?>
                    <button class="add-to-cart-btn out-of-stock" disabled>
                        <i class="fas fa-times"></i>
                        <span><?php _e('ناموجود', 'cafedeluxe'); ?></span>
                    </button>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- کنترل‌های مقدار -->
        <div class="quantity-controls" style="display: none;">
            <button class="quantity-btn minus">
                <i class="fas fa-minus"></i>
            </button>
            <span class="quantity-display">1</span>
            <button class="quantity-btn plus">
                <i class="fas fa-plus"></i>
            </button>
        </div>
    </div>
</div>

<style>
.product-card {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    position: relative;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.product-badges {
    position: absolute;
    top: 15px;
    left: 15px;
    z-index: 2;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.badge {
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 0.7rem;
    font-weight: bold;
    color: white;
}

.badge.sale {
    background: #e74c3c;
}

.badge.out-of-stock {
    background: #95a5a6;
}

.badge.featured {
    background: var(--secondary-color);
    color: #333;
}

.product-image {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.product-card:hover .product-image img {
    transform: scale(1.05);
}

.no-image {
    width: 100%;
    height: 100%;
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
}

.product-actions {
    position: absolute;
    top: 15px;
    right: 15px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    opacity: 0;
    transform: translateX(10px);
    transition: all 0.3s ease;
}

.product-card:hover .product-actions {
    opacity: 1;
    transform: translateX(0);
}

.action-btn {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: white;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
    color: #333;
}

.action-btn:hover {
    background: var(--primary-color);
    color: white;
    transform: scale(1.1);
}

.product-info {
    padding: 20px;
}

.product-category {
    font-size: 0.8rem;
    color: var(--primary-color);
    margin-bottom: 5px;
    font-weight: 500;
}

.product-title {
    margin: 0 0 10px 0;
    font-size: 1.1rem;
    line-height: 1.4;
}

.product-title a {
    color: var(--text-color);
    text-decoration: none;
    transition: color 0.3s;
}

.product-title a:hover {
    color: var(--primary-color);
}

.product-description {
    color: #666;
    font-size: 0.9rem;
    line-height: 1.5;
    margin-bottom: 15px;
}

.product-meta {
    margin-bottom: 15px;
}

.product-rating {
    display: flex;
    align-items: center;
    gap: 5px;
}

.stars {
    color: var(--secondary-color);
}

.rating-count {
    font-size: 0.8rem;
    color: #666;
}

.product-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
}

.product-price {
    font-weight: bold;
    color: var(--primary-color);
    font-size: 1.1rem;
}

.add-to-cart-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 15px;
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.9rem;
    font-weight: 500;
}

.add-to-cart-btn:hover {
    background: var(--accent-color);
    transform: translateY(-2px);
}

.add-to-cart-btn.out-of-stock {
    background: #95a5a6;
    cursor: not-allowed;
}

.add-to-cart-btn.out-of-stock:hover {
    transform: none;
}

.quantity-controls {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    margin-top: 15px;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 8px;
}

.quantity-btn {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    border: 2px solid var(--primary-color);
    background: white;
    color: var(--primary-color);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s;
}

.quantity-btn:hover {
    background: var(--primary-color);
    color: white;
}

.quantity-display {
    font-weight: bold;
    font-size: 1.1rem;
    min-width: 30px;
    text-align: center;
}

/* استایل برای حالت لیست */
.products-list .product-card {
    flex-direction: row;
    align-items: center;
}

.products-list .product-image {
    width: 150px;
    height: 120px;
    flex-shrink: 0;
}

.products-list .product-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.products-list .product-footer {
    margin-top: auto;
}

@media (max-width: 768px) {
    .products-list .product-card {
        flex-direction: column;
    }
    
    .products-list .product-image {
        width: 100%;
        height: 150px;
    }
}
</style>