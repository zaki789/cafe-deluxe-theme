<?php
/**
 * Hero Section Template Part
 */

// دریافت تنظیمات از Customizer
$hero_title = get_theme_mod('hero_title', __('به کافه ما خوش آمدید', 'cafedeluxe'));
$hero_subtitle = get_theme_mod('hero_subtitle', __('لذت طعم بی‌نظیر قهوه و دسرهای خانگی', 'cafedeluxe'));
$button_text = get_theme_mod('hero_button_text', __('مشاهده منو', 'cafedeluxe'));
$button_action = get_theme_mod('hero_button_action', 'scroll');
$button_url = get_theme_mod('hero_button_url', '');
$background_image = get_theme_mod('hero_background_image', '');
$background_color = get_theme_mod('hero_background_color', '#2F4F4F');
?>

<section class="hero-section" id="hero-section">
    <?php if ($background_image): ?>
        <div class="hero-background-image" style="background-image: url('<?php echo esc_url($background_image); ?>');"></div>
    <?php else: ?>
        <div class="hero-background-color" style="background-color: <?php echo esc_attr($background_color); ?>;"></div>
    <?php endif; ?>
    
    <div class="hero-overlay"></div>
    
    <div class="hero-content">
        <div class="hero-text">
            <h1 class="hero-title"><?php echo esc_html($hero_title); ?></h1>
            <p class="hero-subtitle"><?php echo esc_html($hero_subtitle); ?></p>
        </div>
        
        <div class="hero-buttons">
            <?php if ($button_action == 'scroll'): ?>
                <button class="menu-button scroll-to-menu" data-target="menu-section">
                    <?php echo esc_html($button_text); ?>
                </button>
            <?php else: ?>
                <a href="<?php echo esc_url($button_url ?: '#'); ?>" class="menu-button" <?php echo $button_url ? 'target="_blank"' : ''; ?>>
                    <?php echo esc_html($button_text); ?>
                </a>
            <?php endif; ?>
            
            <?php
            // دکمه دوم اختیاری
            $second_button_text = get_theme_mod('hero_second_button_text', '');
            $second_button_url = get_theme_mod('hero_second_button_url', '');
            if ($second_button_text):
            ?>
                <a href="<?php echo esc_url($second_button_url); ?>" class="menu-button secondary">
                    <?php echo esc_html($second_button_text); ?>
                </a>
            <?php endif; ?>
        </div>
        
        <?php
        // ویژگی‌های خاص (اختیاری)
        $features = get_theme_mod('hero_features', array());
        if (!empty($features)):
        ?>
            <div class="hero-features">
                <?php foreach ($features as $feature): ?>
                    <div class="feature-item">
                        <span class="feature-icon"><?php echo esc_html($feature['icon']); ?></span>
                        <span class="feature-text"><?php echo esc_html($feature['text']); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- اسکرول به پایین -->
    <div class="scroll-indicator">
        <div class="scroll-arrow"></div>
    </div>
</section>

<style>
.hero-background-image,
.hero-background-color {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}

.hero-background-image {
    z-index: 1;
}

.hero-background-color {
    z-index: 1;
}

.hero-content {
    position: relative;
    z-index: 3;
    text-align: center;
    color: white;
    max-width: 800px;
    padding: 0 20px;
}

.hero-text {
    margin-bottom: 40px;
}

.hero-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.menu-button.secondary {
    background-color: transparent;
    border: 2px solid white;
    color: white;
}

.menu-button.secondary:hover {
    background-color: white;
    color: var(--primary-color);
}

.hero-features {
    display: flex;
    justify-content: center;
    gap: 40px;
    margin-top: 50px;
    flex-wrap: wrap;
}

.feature-item {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.9rem;
}

.feature-icon {
    font-size: 1.2rem;
}

.scroll-indicator {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 3;
}

.scroll-arrow {
    width: 20px;
    height: 20px;
    border-right: 2px solid white;
    border-bottom: 2px solid white;
    transform: rotate(45deg);
    animation: bounce 2s infinite;
}

@keyframes bounce {
    0%, 100% { transform: rotate(45deg) translateY(0); }
    50% { transform: rotate(45deg) translateY(-10px); }
}

/* ریسپانسیو */
@media (max-width: 768px) {
    .hero-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .hero-features {
        gap: 20px;
    }
    
    .feature-item {
        flex-direction: column;
        text-align: center;
    }
}
</style>