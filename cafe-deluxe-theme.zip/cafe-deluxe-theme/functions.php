<?php
/**
 * CafeDeluxe Theme Functions
 */

// Setup Theme
function cafedeluxe_setup() {
    // Add support for post thumbnails
    add_theme_support('post-thumbnails');
    
    // Add title tag support
    add_theme_support('title-tag');
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('منوی اصلی', 'cafedeluxe'),
        'footer' => __('منوی فوتر', 'cafedeluxe')
    ));
    
    // Add support for WooCommerce
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
    
    // Load text domain
    load_theme_textdomain('cafedeluxe', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'cafedeluxe_setup');

// Enqueue scripts and styles
function cafedeluxe_scripts() {
    // Main stylesheet
    wp_enqueue_style('cafedeluxe-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Custom CSS
    wp_enqueue_style('cafedeluxe-main', get_template_directory_uri() . '/assets/css/main.css', array(), '1.0.0');
    
    // Responsive CSS
    wp_enqueue_style('cafedeluxe-responsive', get_template_directory_uri() . '/assets/css/responsive.css', array('cafedeluxe-main'), '1.0.0');
    
    // Google Fonts
    wp_enqueue_style('cafedeluxe-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Open+Sans:wght@300;400;600;700&display=swap', array(), null);
    
    // jQuery
    wp_enqueue_script('jquery');
    
    // Main JavaScript
    wp_enqueue_script('cafedeluxe-main-js', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0.0', true);
    
    // AJAX Menu JavaScript
    wp_enqueue_script('cafedeluxe-ajax-menu', get_template_directory_uri() . '/assets/js/ajax-menu.js', array('jquery'), '1.0.0', true);
    
    // Localize script for AJAX
    wp_localize_script('cafedeluxe-ajax-menu', 'cafedeluxe_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('cafedeluxe_nonce')
    ));
    
    // Elementor support
    if (did_action('elementor/loaded')) {
        wp_enqueue_style('cafedeluxe-elementor', get_template_directory_uri() . '/assets/css/elementor.css', array(), '1.0.0');
    }
}
add_action('wp_enqueue_scripts', 'cafedeluxe_scripts');

// Include customizer
require get_template_directory() . '/inc/customizer.php';

// Include custom functions
require get_template_directory() . '/inc/custom-functions.php';

// AJAX handler for product filtering
function cafedeluxe_filter_products() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'cafedeluxe_nonce')) {
        wp_die('Invalid nonce');
    }
    
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'post_status' => 'publish'
    );
    
    if ($category_id > 0) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $category_id
            )
        );
    }
    
    $products = new WP_Query($args);
    
    ob_start();
    
    if ($products->have_posts()) {
        while ($products->have_posts()) {
            $products->the_post();
            global $product;
            ?>
            <div class="product-card">
                <div class="product-image">
                    <?php the_post_thumbnail('medium'); ?>
                </div>
                <div class="product-info">
                    <h3 class="product-title"><?php the_title(); ?></h3>
                    <div class="product-description">
                        <?php echo wp_trim_words(get_the_excerpt(), 15); ?>
                    </div>
                    <div class="product-price">
                        <?php echo $product->get_price_html(); ?>
                    </div>
                    <button class="add-to-cart-btn" data-product-id="<?php echo get_the_ID(); ?>">
                        <?php _e('افزودن به سبد خرید', 'cafedeluxe'); ?>
                    </button>
                    <div class="quantity-controls" style="display: none;">
                        <button class="quantity-btn minus">-</button>
                        <span class="quantity-display">1</span>
                        <button class="quantity-btn plus">+</button>
                    </div>
                </div>
            </div>
            <?php
        }
        wp_reset_postdata();
    } else {
        echo '<p class="no-products">' . __('محصولی یافت نشد.', 'cafedeluxe') . '</p>';
    }
    
    $output = ob_get_clean();
    echo $output;
    
    wp_die();
}

add_action('wp_ajax_filter_products', 'cafedeluxe_filter_products');
add_action('wp_ajax_nopriv_filter_products', 'cafedeluxe_filter_products');

// Add to cart functionality
function cafedeluxe_add_to_cart() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'cafedeluxe_nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    
    if ($product_id > 0) {
        // Add to cart
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity);
        
        if ($cart_item_key) {
            wp_send_json_success(array(
                'message' => __('محصول به سبد خرید اضافه شد.', 'cafedeluxe'),
                'cart_count' => WC()->cart->get_cart_contents_count()
            ));
        } else {
            wp_send_json_error(__('خطا در افزودن محصول به سبد خرید.', 'cafedeluxe'));
        }
    } else {
        wp_send_json_error(__('محصول معتبر نیست.', 'cafedeluxe'));
    }
}

add_action('wp_ajax_add_to_cart', 'cafedeluxe_add_to_cart');
add_action('wp_ajax_nopriv_add_to_cart', 'cafedeluxe_add_to_cart');

// AJAX handler for updating cart quantity
function cafedeluxe_update_cart_quantity() {
    if (!wp_verify_nonce($_POST['nonce'], 'cafedeluxe_nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    
    if ($product_id > 0) {
        // Find cart item key
        $cart_item_key = null;
        foreach (WC()->cart->get_cart() as $key => $item) {
            if ($item['product_id'] == $product_id) {
                $cart_item_key = $key;
                break;
            }
        }
        
        if ($cart_item_key) {
            WC()->cart->set_quantity($cart_item_key, $quantity);
            
            wp_send_json_success(array(
                'cart_count' => WC()->cart->get_cart_contents_count()
            ));
        }
    }
    
    wp_send_json_error('Product not found in cart');
}
add_action('wp_ajax_update_cart_quantity', 'cafedeluxe_update_cart_quantity');
add_action('wp_ajax_nopriv_update_cart_quantity', 'cafedeluxe_update_cart_quantity');

// AJAX handler for removing from cart
function cafedeluxe_remove_from_cart() {
    if (!wp_verify_nonce($_POST['nonce'], 'cafedeluxe_nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    
    if ($product_id > 0) {
        // Find cart item key and remove
        foreach (WC()->cart->get_cart() as $key => $item) {
            if ($item['product_id'] == $product_id) {
                WC()->cart->remove_cart_item($key);
                break;
            }
        }
        
        wp_send_json_success(array(
            'cart_count' => WC()->cart->get_cart_contents_count()
        ));
    }
    
    wp_send_json_error('Product not found in cart');
}
add_action('wp_ajax_remove_from_cart', 'cafedeluxe_remove_from_cart');
add_action('wp_ajax_nopriv_remove_from_cart', 'cafedeluxe_remove_from_cart');

// Add Font Awesome icons
function cafedeluxe_add_font_awesome() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0');
}
add_action('wp_enqueue_scripts', 'cafedeluxe_add_font_awesome');

// Create necessary pages on theme activation
function cafedeluxe_create_pages() {
    $pages = array(
        'menu' => array(
            'title' => 'منو',
            'content' => '[cafedeluxe_menu]'
        ),
    );
    
    foreach ($pages as $slug => $page) {
        if (!get_page_by_path($slug)) {
            wp_insert_post(array(
                'post_title' => $page['title'],
                'post_content' => $page['content'],
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_name' => $slug
            ));
        }
    }
}
add_action('after_switch_theme', 'cafedeluxe_create_pages');
?>