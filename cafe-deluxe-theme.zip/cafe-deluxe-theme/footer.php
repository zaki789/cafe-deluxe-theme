<footer class="site-footer">
    <div class="footer-container">
        <?php
        // Display footer information
        cafedeluxe_display_footer_info();
        ?>
        
        <div class="footer-section">
            <h3><?php _e('ساعات کاری', 'cafedeluxe'); ?></h3>
            <p><?php _e('شنبه تا پنجشنبه: ۸ صبح تا ۱۲ شب', 'cafedeluxe'); ?></p>
            <p><?php _e('جمعه: ۱۰ صبح تا ۱۲ شب', 'cafedeluxe'); ?></p>
        </div>
    </div>
    
    <div class="copyright">
        <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('همه حقوق محفوظ است.', 'cafedeluxe'); ?></p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>