php get_header(); 

main id=main-content class=archive-page
    div class=container
        header class=page-header
            h1 class=page-title
                php
                if (is_product_category()) {
                    single_cat_title();
                } else {
                    echo 'محصولات';
                }
                
            h1
        header
        
        div class=products-archive
            php if (have_posts())  
                div class=products-grid
                    php while (have_posts())  the_post(); 
                        php wc_get_template_part('content', 'product'); 
                    php endwhile; 
                div
                
                div class=pagination
                    php
                    the_posts_pagination(array(
                        'prev_text' = 'قبلی',
                        'next_text' = 'بعدی',
                    ));
                    
                div
            php else  
                p class=no-productsمحصولی یافت نشد.p
            php endif; 
        div
    div
main

php get_footer(); 