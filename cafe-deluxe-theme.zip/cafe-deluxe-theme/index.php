<?php get_header(); ?>

<main id="main-content">
    <?php
    // Display hero section
    cafedeluxe_display_hero_section();
    
    // Display AJAX menu section
    cafedeluxe_display_ajax_menu();
    ?>
</main>

<?php get_footer(); ?>