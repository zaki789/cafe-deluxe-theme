/**
 * AJAX Menu Functionality for CafeDeluxe
 */

jQuery(document).ready(function($) {
    // Initialize menu functionality
    function initMenu() {
        // Category filtering
        $('.category-btn').on('click', function() {
            const $this = $(this);
            const categoryId = $this.data('category');
            
            // Remove active class from all buttons
            $('.category-btn').removeClass('active');
            // Add active class to clicked button
            $this.addClass('active');
            
            // Show loading state
            $('#products-container').html(`
                <div class="loading-spinner">
                    <div class="spinner"></div>
                    <p>در حال بارگذاری محصولات...</p>
                </div>
            `);
            
            // AJAX request to filter products
            $.ajax({
                url: cafedeluxe_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'filter_products',
                    category_id: categoryId,
                    nonce: cafedeluxe_ajax.nonce
                },
                success: function(response) {
                    $('#products-container').html(response);
                    initProductInteractions();
                },
                error: function(xhr, status, error) {
                    $('#products-container').html(`
                        <div class="error-message">
                            <p>خطا در بارگذاری محصولات. لطفا دوباره تلاش کنید.</p>
                        </div>
                    `);
                    console.error('AJAX Error:', error);
                }
            });
        });
        
        // Initialize product interactions
        initProductInteractions();
    }
    
    // Initialize product interactions
    function initProductInteractions() {
        // Add to cart functionality
        $('.add-to-cart-btn').on('click', function() {
            const $button = $(this);
            const productId = $button.data('product-id');
            const $card = $button.closest('.product-card');
            const $quantityControls = $card.find('.quantity-controls');
            const $quantityDisplay = $card.find('.quantity-display');
            
            // Hide add button and show quantity controls
            $button.hide();
            $quantityControls.show();
            
            // Add to cart
            addToCart(productId, 1);
        });
        
        // Quantity increase
        $('.quantity-btn.plus').on('click', function() {
            const $display = $(this).siblings('.quantity-display');
            let quantity = parseInt($display.text());
            quantity++;
            $display.text(quantity);
            
            const productId = $(this).closest('.product-card').find('.add-to-cart-btn').data('product-id');
            updateCartQuantity(productId, quantity);
        });
        
        // Quantity decrease
        $('.quantity-btn.minus').on('click', function() {
            const $display = $(this).siblings('.quantity-display');
            let quantity = parseInt($display.text());
            
            if (quantity > 1) {
                quantity--;
                $display.text(quantity);
                const productId = $(this).closest('.product-card').find('.add-to-cart-btn').data('product-id');
                updateCartQuantity(productId, quantity);
            } else {
                // Remove from cart and show add button
                $(this).closest('.quantity-controls').hide();
                $(this).closest('.product-card').find('.add-to-cart-btn').show();
                const productId = $(this).closest('.product-card').find('.add-to-cart-btn').data('product-id');
                removeFromCart(productId);
            }
        });
    }
    
    // Add product to cart
    function addToCart(productId, quantity) {
        $.ajax({
            url: cafedeluxe_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'add_to_cart',
                product_id: productId,
                quantity: quantity,
                nonce: cafedeluxe_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Update cart count
                    $('.cart-count').text(response.data.cart_count);
                    
                    // Show success message
                    showMessage(response.data.message, 'success');
                } else {
                    showMessage(response.data, 'error');
                }
            },
            error: function() {
                showMessage('خطا در ارتباط با سرور', 'error');
            }
        });
    }
    
    // Update cart quantity
    function updateCartQuantity(productId, quantity) {
        $.ajax({
            url: cafedeluxe_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'update_cart_quantity',
                product_id: productId,
                quantity: quantity,
                nonce: cafedeluxe_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('.cart-count').text(response.data.cart_count);
                }
            }
        });
    }
    
    // Remove from cart
    function removeFromCart(productId) {
        $.ajax({
            url: cafedeluxe_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'remove_from_cart',
                product_id: productId,
                nonce: cafedeluxe_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('.cart-count').text(response.data.cart_count);
                    showMessage('محصول از سبد خرید حذف شد', 'info');
                }
            }
        });
    }
    
    // Show message to user
    function showMessage(message, type) {
        // Remove existing messages
        $('.cart-message').remove();
        
        // Create new message
        const $message = $(`
            <div class="cart-message ${type}">
                <span>${message}</span>
            </div>
        `);
        
        // Add to page
        $('body').append($message);
        
        // Show and auto-hide
        $message.fadeIn(300).delay(3000).fadeOut(300, function() {
            $(this).remove();
        });
    }
    
    // Initialize menu when document is ready
    initMenu();
});