/**
 * CafeDeluxe Main JavaScript
 */

jQuery(document).ready(function($) {
    // Scroll to menu section
    $('.scroll-to-menu').on('click', function() {
        $('html, body').animate({
            scrollTop: $('#menu-section').offset().top - 100
        }, 1000);
    });
    
    // Product category filtering
    $('.category-btn').on('click', function() {
        // Update active button
        $('.category-btn').removeClass('active');
        $(this).addClass('active');
        
        // Get category ID
        var categoryId = $(this).data('category');
        
        // Show loading state
        $('#products-container').html('<div class="loading">در حال بارگذاری...</div>');
        
        // AJAX request
        $.ajax({
            url: cafedeluxe_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'filter_products',
                category_id: categoryId,
                nonce: cafedeluxe_ajax.nonce
            },
            success: function(response) {
                $('#products-container').html(response);
                initializeProductInteractions();
            },
            error: function() {
                $('#products-container').html('<p class="error">خطا در بارگذاری محصولات</p>');
            }
        });
    });
    
    // Initialize product interactions
    function initializeProductInteractions() {
        // Add to cart functionality
        $('.add-to-cart-btn').on('click', function() {
            var productId = $(this).data('product-id');
            var $card = $(this).closest('.product-card');
            var $quantityControls = $card.find('.quantity-controls');
            var $quantityDisplay = $card.find('.quantity-display');
            var quantity = 1;
            
            // Hide add to cart button, show quantity controls
            $(this).hide();
            $quantityControls.show();
            
            // Update cart via AJAX
            updateCart(productId, quantity);
        });
        
        // Quantity controls
        $('.quantity-btn.plus').on('click', function() {
            var $display = $(this).siblings('.quantity-display');
            var quantity = parseInt($display.text()) + 1;
            $display.text(quantity);
            
            var productId = $(this).closest('.product-card').find('.add-to-cart-btn').data('product-id');
            updateCart(productId, quantity);
        });
        
        $('.quantity-btn.minus').on('click', function() {
            var $display = $(this).siblings('.quantity-display');
            var quantity = parseInt($display.text()) - 1;
            
            if (quantity <= 0) {
                // Hide quantity controls, show add to cart button
                $(this).closest('.quantity-controls').hide();
                $(this).closest('.product-card').find('.add-to-cart-btn').show();
                quantity = 0;
            } else {
                $display.text(quantity);
            }
            
            var productId = $(this).closest('.product-card').find('.add-to-cart-btn').data('product-id');
            updateCart(productId, quantity);
        });
    }
    
    // Update cart function
    function updateCart(productId, quantity) {
        $.ajax({
            url: cafedeluxe_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'add_to_cart',
                product_id: productId,
                quantity: quantity,
                nonce: cafedeluxe_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Update cart count
                    $('.cart-count').text(response.data.cart_count);
                    
                    // Show success message
                    showMessage(response.data.message, 'success');
                } else {
                    showMessage(response.data, 'error');
                }
            },
            error: function() {
                showMessage('خطا در ارتباط با سرور', 'error');
            }
        });
    }
    
    // Show message function
    function showMessage(message, type) {
        var $message = $('<div class="cart-message ' + type + '">' + message + '</div>');
        $('body').append($message);
        
        $message.fadeIn().delay(3000).fadeOut(function() {
            $(this).remove();
        });
    }
    
    // Initialize on page load
    initializeProductInteractions();
    
    // Mobile menu toggle
    $('.mobile-menu-toggle').on('click', function() {
        $('.main-navigation').toggleClass('active');
    });
});