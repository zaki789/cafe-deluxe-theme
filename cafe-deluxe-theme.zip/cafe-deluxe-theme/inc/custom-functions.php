<?php
/**
 * Custom functions for CafeDeluxe theme
 */

// Get WooCommerce categories with icons
function cafedeluxe_get_product_categories() {
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => true,
    ));
    
    return $categories;
}

// Display hero section
function cafedeluxe_display_hero_section() {
    $hero_title = get_theme_mod('hero_title', __('به کافه ما خوش آمدید', 'cafedeluxe'));
    $hero_subtitle = get_theme_mod('hero_subtitle', __('لذت طعم بی‌نظیر قهوه و دسرهای خانگی', 'cafedeluxe'));
    $button_text = get_theme_mod('hero_button_text', __('مشاهده منو', 'cafedeluxe'));
    $button_action = get_theme_mod('hero_button_action', 'scroll');
    $button_url = get_theme_mod('hero_button_url', '');
    ?>
    
    <section class="hero-section">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1 class="hero-title"><?php echo esc_html($hero_title); ?></h1>
            <p class="hero-subtitle"><?php echo esc_html($hero_subtitle); ?></p>
            
            <?php if ($button_action == 'scroll'): ?>
                <button class="menu-button scroll-to-menu"><?php echo esc_html($button_text); ?></button>
            <?php else: ?>
                <a href="<?php echo esc_url($button_url); ?>" class="menu-button"><?php echo esc_html($button_text); ?></a>
            <?php endif; ?>
        </div>
    </section>
    
    <?php
}

// Display AJAX menu section
function cafedeluxe_display_ajax_menu() {
    $categories = cafedeluxe_get_product_categories();
    ?>
    
    <section class="menu-section" id="menu-section">
        <h2 class="section-title"><?php _e('منوی ما', 'cafedeluxe'); ?></h2>
        
        <div class="menu-categories">
            <button class="category-btn active" data-category="0"><?php _e('همه', 'cafedeluxe'); ?></button>
            <?php foreach ($categories as $category): ?>
                <button class="category-btn" data-category="<?php echo $category->term_id; ?>">
                    <?php echo $category->name; ?>
                </button>
            <?php endforeach; ?>
        </div>
        
        <div class="products-grid" id="products-container">
            <?php
            // Display all products initially
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'post_status' => 'publish'
            );
            
            $products = new WP_Query($args);
            
            if ($products->have_posts()) {
                while ($products->have_posts()) {
                    $products->the_post();
                    global $product;
                    ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php the_post_thumbnail('medium'); ?>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title"><?php the_title(); ?></h3>
                            <div class="product-description">
                                <?php echo wp_trim_words(get_the_excerpt(), 15); ?>
                            </div>
                            <div class="product-price">
                                <?php echo $product->get_price_html(); ?>
                            </div>
                            <button class="add-to-cart-btn" data-product-id="<?php echo get_the_ID(); ?>">
                                <?php _e('افزودن به سبد خرید', 'cafedeluxe'); ?>
                            </button>
                            <div class="quantity-controls" style="display: none;">
                                <button class="quantity-btn minus">-</button>
                                <span class="quantity-display">1</span>
                                <button class="quantity-btn plus">+</button>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                wp_reset_postdata();
            } else {
                echo '<p class="no-products">' . __('محصولی یافت نشد.', 'cafedeluxe') . '</p>';
            }
            ?>
        </div>
    </section>
    
    <?php
}

// Display footer information
function cafedeluxe_display_footer_info() {
    $address = get_theme_mod('footer_address', __('تهران، خیابان مثال، پلاک 123', 'cafedeluxe'));
    $phone = get_theme_mod('footer_phone', '021-12345678');
    $instagram = get_theme_mod('footer_instagram', 'https://instagram.com/yourcafe');
    ?>
    
    <div class="footer-section">
        <h3><?php _e('آدرس ما', 'cafedeluxe'); ?></h3>
        <p><?php echo esc_html($address); ?></p>
    </div>
    
    <div class="footer-section">
        <h3><?php _e('تماس با ما', 'cafedeluxe'); ?></h3>
        <p><?php echo esc_html($phone); ?></p>
    </div>
    
    <div class="footer-section">
        <h3><?php _e('شبکه‌های اجتماعی', 'cafedeluxe'); ?></h3>
        <div class="social-icons">
            <a href="<?php echo esc_url($instagram); ?>" class="social-icon" target="_blank">
                <i class="fab fa-instagram"></i>
            </a>
        </div>
    </div>
    
    <?php
}
?>