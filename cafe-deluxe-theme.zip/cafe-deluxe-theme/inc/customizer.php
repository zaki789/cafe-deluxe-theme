<?php
/**
 * CafeDeluxe Theme Customizer
 */

function cafedeluxe_customize_register($wp_customize) {
    // Section for Header Settings
    $wp_customize->add_section('cafedeluxe_header_section', array(
        'title' => __('تنظیمات هدر', 'cafedeluxe'),
        'priority' => 30,
    ));
    
    // Logo Upload
    $wp_customize->add_setting('cafedeluxe_logo', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'cafedeluxe_logo', array(
        'label' => __('آپلود لوگو', 'cafedeluxe'),
        'section' => 'cafedeluxe_header_section',
        'settings' => 'cafedeluxe_logo',
    )));
    
    // Site Title Color
    $wp_customize->add_setting('site_title_color', array(
        'default' => '#8B4513',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'site_title_color', array(
        'label' => __('رنگ عنوان سایت', 'cafedeluxe'),
        'section' => 'cafedeluxe_header_section',
        'settings' => 'site_title_color',
    )));
    
    // Section for Hero Section
    $wp_customize->add_section('cafedeluxe_hero_section', array(
        'title' => __('بخش اصلی صفحه اصلی', 'cafedeluxe'),
        'priority' => 40,
    ));
    
    // Hero Background Image
    $wp_customize->add_setting('hero_background_image', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'hero_background_image', array(
        'label' => __('تصویر پس‌زمینه بخش اصلی', 'cafedeluxe'),
        'section' => 'cafedeluxe_hero_section',
        'settings' => 'hero_background_image',
    )));
    
    // Hero Background Color (fallback)
    $wp_customize->add_setting('hero_background_color', array(
        'default' => '#2F4F4F',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'hero_background_color', array(
        'label' => __('رنگ پس‌زمینه بخش اصلی (جایگزین تصویر)', 'cafedeluxe'),
        'section' => 'cafedeluxe_hero_section',
        'settings' => 'hero_background_color',
    )));
    
    // Hero Title
    $wp_customize->add_setting('hero_title', array(
        'default' => __('به کافه ما خوش آمدید', 'cafedeluxe'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('عنوان بخش اصلی', 'cafedeluxe'),
        'section' => 'cafedeluxe_hero_section',
        'type' => 'text',
    ));
    
    // Hero Subtitle
    $wp_customize->add_setting('hero_subtitle', array(
        'default' => __('لذت طعم بی‌نظیر قهوه و دسرهای خانگی', 'cafedeluxe'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_subtitle', array(
        'label' => __('زیرعنوان بخش اصلی', 'cafedeluxe'),
        'section' => 'cafedeluxe_hero_section',
        'type' => 'textarea',
    ));
    
    // Button Text
    $wp_customize->add_setting('hero_button_text', array(
        'default' => __('مشاهده منو', 'cafedeluxe'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_button_text', array(
        'label' => __('متن دکمه بخش اصلی', 'cafedeluxe'),
        'section' => 'cafedeluxe_hero_section',
        'type' => 'text',
    ));
    
    // Button Action
    $wp_customize->add_setting('hero_button_action', array(
        'default' => 'scroll',
        'sanitize_callback' => 'cafedeluxe_sanitize_button_action',
    ));
    
    $wp_customize->add_control('hero_button_action', array(
        'label' => __('عملکرد دکمه', 'cafedeluxe'),
        'section' => 'cafedeluxe_hero_section',
        'type' => 'select',
        'choices' => array(
            'scroll' => __('اسکرول به بخش منو', 'cafedeluxe'),
            'new_page' => __('باز کردن صفحه جدید', 'cafedeluxe'),
        ),
    ));
    
    // Button URL (if new page selected)
    $wp_customize->add_setting('hero_button_url', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('hero_button_url', array(
        'label' => __('آدرس دکمه (اگر عملکرد صفحه جدید است)', 'cafedeluxe'),
        'section' => 'cafedeluxe_hero_section',
        'type' => 'url',
    ));
    
    // Button Size
    $wp_customize->add_setting('hero_button_size', array(
        'default' => 'medium',
        'sanitize_callback' => 'cafedeluxe_sanitize_button_size',
    ));
    
    $wp_customize->add_control('hero_button_size', array(
        'label' => __('سایز دکمه', 'cafedeluxe'),
        'section' => 'cafedeluxe_hero_section',
        'type' => 'select',
        'choices' => array(
            'small' => __('کوچک', 'cafedeluxe'),
            'medium' => __('متوسط', 'cafedeluxe'),
            'large' => __('بزرگ', 'cafedeluxe'),
        ),
    ));
    
    // Section for Color Settings
    $wp_customize->add_section('cafedeluxe_color_section', array(
        'title' => __('تنظیمات رنگ‌ها', 'cafedeluxe'),
        'priority' => 50,
    ));
    
    // Primary Color
    $wp_customize->add_setting('primary_color', array(
        'default' => '#8B4513',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', array(
        'label' => __('رنگ اصلی', 'cafedeluxe'),
        'section' => 'cafedeluxe_color_section',
        'settings' => 'primary_color',
    )));
    
    // Secondary Color
    $wp_customize->add_setting('secondary_color', array(
        'default' => '#D4AF37',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_color', array(
        'label' => __('رنگ ثانویه', 'cafedeluxe'),
        'section' => 'cafedeluxe_color_section',
        'settings' => 'secondary_color',
    )));
    
    // Accent Color
    $wp_customize->add_setting('accent_color', array(
        'default' => '#2F4F4F',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'accent_color', array(
        'label' => __('رنگ تأکیدی', 'cafedeluxe'),
        'section' => 'cafedeluxe_color_section',
        'settings' => 'accent_color',
    )));
    
    // Text Color
    $wp_customize->add_setting('text_color', array(
        'default' => '#333333',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'text_color', array(
        'label' => __('رنگ متن', 'cafedeluxe'),
        'section' => 'cafedeluxe_color_section',
        'settings' => 'text_color',
    )));
    
    // Background Color
    $wp_customize->add_setting('background_color', array(
        'default' => '#FFFFFF',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'background_color', array(
        'label' => __('رنگ پس‌زمینه', 'cafedeluxe'),
        'section' => 'cafedeluxe_color_section',
        'settings' => 'background_color',
    )));
    
    // Button Background Color
    $wp_customize->add_setting('button_bg_color', array(
        'default' => '#8B4513',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button_bg_color', array(
        'label' => __('رنگ پس‌زمینه دکمه', 'cafedeluxe'),
        'section' => 'cafedeluxe_color_section',
        'settings' => 'button_bg_color',
    )));
    
    // Button Text Color
    $wp_customize->add_setting('button_text_color', array(
        'default' => '#FFFFFF',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button_text_color', array(
        'label' => __('رنگ متن دکمه', 'cafedeluxe'),
        'section' => 'cafedeluxe_color_section',
        'settings' => 'button_text_color',
    ));
    
    // Section for Typography
    $wp_customize->add_section('cafedeluxe_typography_section', array(
        'title' => __('تنظیمات فونت', 'cafedeluxe'),
        'priority' => 60,
    ));
    
    // Heading Font
    $wp_customize->add_setting('heading_font', array(
        'default' => "'Playfair Display', serif",
        'sanitize_callback' => 'cafedeluxe_sanitize_font',
    ));
    
    $wp_customize->add_control('heading_font', array(
        'label' => __('فونت عناوین', 'cafedeluxe'),
        'section' => 'cafedeluxe_typography_section',
        'type' => 'select',
        'choices' => array(
            "'Playfair Display', serif" => 'Playfair Display',
            "'Georgia', serif" => 'Georgia',
            "'Arial', sans-serif" => 'Arial',
            "'Tahoma', sans-serif" => 'Tahoma',
        ),
    ));
    
    // Body Font
    $wp_customize->add_setting('body_font', array(
        'default' => "'Open Sans', sans-serif",
        'sanitize_callback' => 'cafedeluxe_sanitize_font',
    ));
    
    $wp_customize->add_control('body_font', array(
        'label' => __('فونت متن', 'cafedeluxe'),
        'section' => 'cafedeluxe_typography_section',
        'type' => 'select',
        'choices' => array(
            "'Open Sans', sans-serif" => 'Open Sans',
            "'Arial', sans-serif" => 'Arial',
            "'Tahoma', sans-serif" => 'Tahoma',
            "'Roboto', sans-serif" => 'Roboto',
        ),
    ));
    
    // Section for Footer
    $wp_customize->add_section('cafedeluxe_footer_section', array(
        'title' => __('تنظیمات فوتر', 'cafedeluxe'),
        'priority' => 70,
    ));
    
    // Footer Address
    $wp_customize->add_setting('footer_address', array(
        'default' => __('تهران، خیابان مثال، پلاک 123', 'cafedeluxe'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('footer_address', array(
        'label' => __('آدرس', 'cafedeluxe'),
        'section' => 'cafedeluxe_footer_section',
        'type' => 'textarea',
    ));
    
    // Footer Phone
    $wp_customize->add_setting('footer_phone', array(
        'default' => '021-12345678',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('footer_phone', array(
        'label' => __('شماره تماس', 'cafedeluxe'),
        'section' => 'cafedeluxe_footer_section',
        'type' => 'text',
    ));
    
    // Footer Instagram
    $wp_customize->add_setting('footer_instagram', array(
        'default' => 'https://instagram.com/yourcafe',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('footer_instagram', array(
        'label' => __('آدرس اینستاگرام', 'cafedeluxe'),
        'section' => 'cafedeluxe_footer_section',
        'type' => 'url',
    ));
}

add_action('customize_register', 'cafedeluxe_customize_register');

// Sanitization functions
function cafedeluxe_sanitize_button_action($input) {
    $valid = array('scroll', 'new_page');
    if (in_array($input, $valid)) {
        return $input;
    }
    return 'scroll';
}

function cafedeluxe_sanitize_button_size($input) {
    $valid = array('small', 'medium', 'large');
    if (in_array($input, $valid)) {
        return $input;
    }
    return 'medium';
}

function cafedeluxe_sanitize_font($input) {
    $valid = array(
        "'Playfair Display', serif",
        "'Georgia', serif",
        "'Arial', sans-serif",
        "'Tahoma', sans-serif",
        "'Open Sans', sans-serif",
        "'Roboto', sans-serif"
    );
    if (in_array($input, $valid)) {
        return $input;
    }
    return "'Open Sans', sans-serif";
}

// Output custom CSS based on Customizer settings
function cafedeluxe_customizer_css() {
    ?>
    <style type="text/css">
        :root {
            --primary-color: <?php echo get_theme_mod('primary_color', '#8B4513'); ?>;
            --secondary-color: <?php echo get_theme_mod('secondary_color', '#D4AF37'); ?>;
            --accent-color: <?php echo get_theme_mod('accent_color', '#2F4F4F'); ?>;
            --text-color: <?php echo get_theme_mod('text_color', '#333333'); ?>;
            --background-color: <?php echo get_theme_mod('background_color', '#FFFFFF'); ?>;
            --button-bg-color: <?php echo get_theme_mod('button_bg_color', '#8B4513'); ?>;
            --button-text-color: <?php echo get_theme_mod('button_text_color', '#FFFFFF'); ?>;
            --heading-font: <?php echo get_theme_mod('heading_font', "'Playfair Display', serif"); ?>;
            --body-font: <?php echo get_theme_mod('body_font', "'Open Sans', sans-serif"); ?>;
        }
        
        .site-title {
            color: <?php echo get_theme_mod('site_title_color', '#8B4513'); ?>;
        }
        
        .hero-section {
            <?php if (get_theme_mod('hero_background_image')): ?>
            background-image: url('<?php echo get_theme_mod('hero_background_image'); ?>');
            <?php else: ?>
            background-color: <?php echo get_theme_mod('hero_background_color', '#2F4F4F'); ?>;
            <?php endif; ?>
        }
        
        .menu-button {
            <?php
            $button_size = get_theme_mod('hero_button_size', 'medium');
            if ($button_size == 'small') {
                echo 'padding: 10px 25px; font-size: 1rem;';
            } elseif ($button_size == 'large') {
                echo 'padding: 20px 50px; font-size: 1.4rem;';
            } else {
                echo 'padding: 15px 40px; font-size: 1.2rem;';
            }
            ?>
        }
    </style>
    <?php
}
add_action('wp_head', 'cafedeluxe_customizer_css');
?>